package model.room.entity.Account;

public enum RightsEnum {
    User(),
    Supervisor(),
    Owner();
}
