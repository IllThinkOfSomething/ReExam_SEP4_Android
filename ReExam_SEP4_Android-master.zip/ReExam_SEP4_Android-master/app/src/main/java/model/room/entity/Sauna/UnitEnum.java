package model.room.entity.Sauna;

public enum UnitEnum {
    CENTIGRADE,
    PPM,
    PERCENT;
}
